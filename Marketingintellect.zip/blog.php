<?Php
if($_POST["Submit"])
{
$Title=$_POST["ar1"];
$meta_keyword=$_POST['area2'];
$meta_title=$_POST["area3"];
$meta_description=$_POST["area4"];
$Heading=$_POST["area5"];
$Content=$_POST["area6"];
echo $Title;
echo "9";
$newblog=fopen("Blogs/" . str_replace(" ", "", $Title) . ".html","w");
$txt = "<Html>\n\t<head>\n\t\t<title>\n\t\t\t".$Title."\n\t\t</title>";
fwrite($newblog, $txt);
$meta_descrip="\n\t\t<meta name='description' content='".$meta_description."'>";
fwrite($newblog, $meta_descrip);
$meta_key="\n\t\t<meta name='keywords' content='".$meta_keyword."'>";
fwrite($newblog, $meta_key);
$sty_scripts="\n\t\t<link rel='icon' href='favicon.ico' type='image/x-icon'>\n\t\t
        <link href='https://fonts.googleapis.com/css2?family=Montserrat:wght@900&ampdisplay=swap' rel='stylesheet'>\n\t\t
        <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css' integrity='sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T' crossorigin='anonymous'>\n\t\t
        
        <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.8.2/css/all.css' integrity='sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay' crossorigin='anonymous'>\n\t</head>";
fwrite($newblog, $sty_scripts);
$nav="\n\t<body class='bg-light'>\n\t\t<nav class=' navbar navbar-expand-lg fixed-top ' style='background-color: #dbeaf6ea;'>
        
            \n\t\t<a class='navbar-brand' href='#'>Marketing Intellect</a>
            \n\t\t<button class='navbar-toggler navbar-toggler-right' type='button' data-toggle='collapse' data-target='#navbarResponsive' >
              \n\t\t\t Menu
              \n\t\t\t <i class='fas fa-bars'></i>
            \n\t\t</button>
            \n\t\t<div class='collapse navbar-collapse' id='navbarResponsive'>
              \n\t\t\t <ul class='navbar-nav ml-auto'>
                \n\t\t\t\t <li class='nav-item ml-3'>
                  \n\t\t\t\t\t <a class='nav-link ' href='../index.html'>Home</a>
                \n\t\t\t\t </li>
                \n\t\t\t\t <li class='nav-item '>
                  \n\t\t\t\t<div class='dropdown'>
                    \n\t\t\t\t\t<button type='button' class='btn dropdown-toggle ' data-toggle='dropdown'>
                      \n\t\t\t\t\t Services
                    \n\t\t\t\t\t</button>
                    <div class='dropdown-menu'>
                      <a class='dropdown-item' href='../Marketing.html'>Digital Marketing</a>
                      <a class='dropdown-item' href='../Dashboard.html'>Dashboard Services</a>
                      <a class='dropdown-item' href='../Analytics.html'>Analytics Services</a>
                      
                    </div>
                  </div>
                </li>
                <li class='nav-item ml-2'>
                  <a class='nav-link ' href='All_Blogs.php'>Blogs</a>
                </li>
                <li class='nav-item ml-3'>
                  <a class='nav-link ' href='#Contact'>Contact Us</a>
                </li>
              </ul>
            </div>
          
    </nav>
    <br><br><br>";
fwrite($newblog, $nav);
$headline="\n\t\t<center><h1>".$Heading."</h1></center><br>\n\t\t";
fwrite($newblog, $headline);
$content="<br>
        <div class='container'>
            <div class='row'>
            <div class='col-sm-12'>\n".$Content."\n</div>
            </div>
            </div>";
fwrite($newblog, $content);
$end="\n<section class='contact-section' id='Contact' style='background-color:#475158;position: absolute; bottom: 2px;margin-left:1%;min-width:98%;'>
    <div class='container mb-2'>
      <div class='row'>
        <div class='col-sm-12 mb-4 mt-5 my-2'>
          <div class='card-deck' style='align-items: center;'>
            <div class='card py-4 w-100'>
              <div class='card-body text-center '>
              <i class='fas fa-map-marked-alt text-primary mb-2 fa-2x'></i>
             <h4 class='text-uppercase m-0'>Address</h4>
                <hr class='my-4'>
                <div class='small text-black-30'>Gurgaon</div>
              </div>
            </div>       
            <div class='card py-4 w-100'>
              <div class='card-body text-center '>
                <i class='fas fa-envelope text-primary mb-2 fa-2x'></i>
                <h4 class='text-uppercase m-0'>Email</h4>
                <hr class='my-4'>
                <div class='small text-black-30'>
                  anubhutipandey15@gmail.com
                </div>
              </div>
            </div>    
          </div>
        
        </div>
        
      </div>
      
    </div>
    
  </section>
  <script src='https://code.jquery.com/jquery-3.3.1.slim.min.js' integrity='sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo' crossorigin='anonymous'></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js' integrity='sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1' crossorigin='anonymous'></script>
  <script src='https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js' integrity='sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM' crossorigin='anonymous'></script>
</body>
</html>";
fwrite($newblog, $end);
echo 
        "<script>
            alert('Blog Uploaded');
            window.location='Blogs/".str_replace(' ', '', $Title) . ".html'; </script>";
}
?>